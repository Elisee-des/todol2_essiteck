import {Fragment, useState} from 'react'

const InfoPersonne = (props) => (
  <Fragment>
    <h1>Bonjour</h1>
    <p>Nom:  {props?.name}</p>
    <p>Age:  {props?.age}</p>
    <p>{`Votre nom compte ${props?.name?.length} caractère${props?.name?.length > 1 ? 's' : ''}`}</p>
    <p>Vous avez {`${props?.age} ans`}</p>
  </Fragment>
)

const SectionContent = ({title, subTitle, children}) => {
  return(
    <div>
      <div>
        <h5>{title}</h5>
        <h6>{subTitle}</h6>
      </div>
      <div>{children}</div>
    </div>
  )
}


function App() {
  const name = "p";
  const [age, setAge] = useState(130);
  const [show, setShow] = useState(true);
  

  const handleSetAge = (e) => {
    e.preventDefault();
    setAge(60);
    setShow(false)
  }
  return (
    <Fragment>
      <SectionContent title={"Information sur son profile"} subTitle={"Profil"}>
        <InfoPersonne name={name} age={age} />
      </SectionContent>
      <p>
        {show ? <button onClick={handleSetAge} >MODIFIER AGE</button> : ""}
      </p>
    </Fragment>
  );
}

export default App;
