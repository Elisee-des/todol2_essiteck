import {useRef, useState} from 'react'

// const FormTodo = () => {
//     const inputField = useRef();
//     const [inputValue, setInputValue] = useState('')
//     const handlerSubmit = (event) => {
//         event.preventDefault();
//         const value = inputField?.current?.value ?? '';
//         setInputValue(value)
//     }
//     return (
//       <div>
//           <form onSubmit={handlerSubmit}>
//             <input type={'text'} ref={inputField} />
//             <button type='submit'>AFFICHER LA SAISIE</button>
//           </form>
//           <p>{inputValue}</p>
//       </div>
//     )
// }

export default FormTodo
